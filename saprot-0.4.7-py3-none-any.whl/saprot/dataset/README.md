# Introduction
## lmdb_dataset.py
The `lmdb_dataset.py` file contains the abstract class for all datasets.

## data_interface.py
The `data_interface.py` file is used to dynamically load a dataset.

## saprot
The `saprot` folder contains various implementations for loading datasets for SaProt model and ESM models.
