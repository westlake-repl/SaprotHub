import sys
import os
current_file = os.path.abspath(__file__)
saprot_dir = os.path.dirname(current_file)
sys.path.append(saprot_dir)